/*
 * tests.h
 *
 *  Created on: 18-mars-2009
 *      Author: yki
 */

#ifndef TESTS_H_
#define TESTS_H_

extern int tests();

#endif /* TESTS_H_ */
