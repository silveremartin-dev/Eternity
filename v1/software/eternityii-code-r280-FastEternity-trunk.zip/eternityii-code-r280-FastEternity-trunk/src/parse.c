/*
 * parse.c
 *
 *  Created on: 18-mars-2009
 *      Author: yki
 */

#include <stdio.h>

#include "puzzle.h"

void parseGrid(quad_t* grid, FILE* file) {
	gridoffset_t i;
	direction_t d;

	for (i = 0; i < GRID_POSITIONS; i++) {
		quad_t quad = 0;

		for (d = 0; d < 4; d++) {
			int pattern;
			fscanf(file, "%d", &pattern);
			SET_QUAD_PATTERN(quad, d, (pattern_t) pattern);
		}

		grid[i] = quad;
	}
}

void dumpGrid(quad_t* grid) {
	gridoffset_t i;
	direction_t d;

	for (i = 0; i < GRID_POSITIONS; i++) {
		quad_t quad = grid[i];

		for (d = 0; d < 4; d++) {
			printf("%2d ", GET_QUAD_PATTERN(quad, d));
		}

		if ((i % GRID_SIZE) == GRID_SIZE - 1) {
			printf("\n");
		}
	}
}
