/*
 * solver_mkV.h
 *
 *  Created on: 7 mars 2009
 *      Author: Yannick Kirschhoffer
 */

#ifndef SOLVER_MKV_H_
#define SOLVER_MKV_H_

#include "puzzle.h"

extern int solve_mkV(quad_t* grid);

#endif /* SOLVER_MKV_H_ */
