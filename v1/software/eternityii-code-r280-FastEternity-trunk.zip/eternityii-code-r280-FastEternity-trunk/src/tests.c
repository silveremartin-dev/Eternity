/*
 * Tests.c
 *
 *  Created on: 18-mars-2009
 *      Author: Yannick Kirschhoffer
 */

#include <stdio.h>

#include "puzzle.h"

int tests() {
	int result = 1;
	printf("Running tests...\n");

	if (result) {
		printf(" - Quad construction\n");
		result = (result && QUAD(1,2,3,4) == 0x04030201);
	}

	if (result) {
		printf(" - Quad getters\n");

		quad_t quad = QUAD(1,2,3,4);
		result = (result && (GET_QUAD_PATTERN(quad,DIR_NORTH) == 1)
				&& (GET_QUAD_PATTERN(quad,DIR_EAST) == 2)
				&& (GET_QUAD_PATTERN(quad,DIR_SOUTH) == 3)
				&& (GET_QUAD_PATTERN(quad,DIR_WEST) == 4));
	}

	if (result) {
		printf(" - Quad matching\n");

		quad_t quad = QUAD(1,2,3,4);
		quad_t quad_1_1 = QUAD(6,2,8,9);
		quad_t quad_1_2 = QUAD(6,7,2,9);
		quad_t quad_3_1 = QUAD(3,7,1,2);
		u8 degrees;
		MATCH_DEGREES(quad, quad_1_1, degrees);
		result = (result && (degrees == 1));
		MATCH_DEGREES(quad, quad_1_2, degrees);
		result = (result && (degrees == 1));
		MATCH_DEGREES(quad, quad_3_1, degrees);
		result = (result && (degrees == 3));

		degrees = _MD(QUAD(0,2,3,0),QUAD(7,8,0,0),0);
		result = (result && (degrees == 1));
		MATCH_DEGREES(QUAD(0,2,3,0),QUAD(7,8,0,0), degrees);
		result = (result && (degrees == 2));
	}

	if (result) {
		printf(" - Quad rotation\n");
		quad_t quad = QUAD(1,2,3,4);

		quad = _ROL32(quad, 8);
		result = (result && (quad == QUAD(4,1,2,3)));
		quad = _ROL32(quad, 8);
		result = (result && (quad == QUAD(3,4,1,2)));
		quad = _ROL32(quad, 8);
		result = (result && (quad == QUAD(2,3,4,1)));
		quad = _ROL32(quad, 8);
		result = (result && (quad == QUAD(1,2,3,4)));
	}

	if (result) {
		printf(" - Quad optimization\n");

		quad_t quadA1 = QUAD(1,2,3,4);
		quad_t quadA2 = QUAD(2,7,4,9);

		quad_t quadB1 = QUAD(0,1,2,0);
		quad_t quadB2 = QUAD(2,0,0,1);

		quad_t quadC1 = QUAD(1,2,0,0);
		quad_t quadC2 = QUAD(8,0,0,7);

		quad_t quadD1 = QUAD(1,0,2,3);
		quad_t quadD2 = QUAD(7,2,3,0);

		OPTIMIZE_QUAD_ROTATION(quadA2, quadA1);
		result = (result && (quadA2 == QUAD(9,2,7,4)));

		OPTIMIZE_QUAD_ROTATION(quadB2, quadB1);
		result = (result && (quadB2 == QUAD(0,1,2,0)));

		OPTIMIZE_QUAD_ROTATION(quadC2, quadC1);
		result = (result && (quadC2 == QUAD(7,8,0,0)));

		OPTIMIZE_QUAD_ROTATION(quadD2, quadD1);
		result = (result && (quadD2 == QUAD(3,0,7,2)));
	}

	if (result) {
		printf(" - Quad position evaluation\n");

		quad_t grid[GRID_POSITIONS];
		grid[0] = QUAD(0,1,2,0);
		grid[1] = QUAD(0,3,3,1);
		grid[GRID_SIZE] = QUAD(2,3,3,0);

		result = (result && MATCHING_DIRECTION(grid, 0, 0) == 1);
		result = (result && MATCHING_DIRECTION(grid, 0, 1) == 1);
		result = (result && MATCHING_DIRECTION(grid, 0, 2) == 1);
		result = (result && MATCHING_DIRECTION(grid, 0, 3) == 1);
	}

	if (result) {
		printf(" - Quad swapping\n");

		quad_t grid[GRID_POSITIONS];
		gridoffset_t i;

		for (i = 0; i < GRID_POSITIONS; i++) {
			grid[i] = QUAD(1,1,1,1);
		}

		for (i = 0; i < GRID_POSITIONS; i++) {
			gridoffset_t oA = lrand48() % GRID_POSITIONS;
			gridoffset_t oB = lrand48() % (GRID_POSITIONS - 1);
			if (oB >= oA) {
				oB++;
			}

			GRID_SWAP(grid, oA, oB);
		}

		for (i = 0; i < GRID_POSITIONS; i++) {
			if (grid[i] != QUAD(1,1,1,1)) {
				result = 0;
			}
		}
	}

	return result;
}
