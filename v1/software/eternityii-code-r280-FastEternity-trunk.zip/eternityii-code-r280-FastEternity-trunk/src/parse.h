/*
 * parse.h
 *
 *  Created on: 18-mars-2009
 *      Author: Yannick Kirschhoffer
 */

#ifndef PARSE_H_
#define PARSE_H_

extern void parseGrid(quad_t* grid, FILE* file);
extern void dumpGrid(quad_t* grid);

#endif /* PARSE_H_ */
