/*
 ============================================================================
 Name        : FastEternity.c
 Author      :
 Version     :
 Copyright   : Yannick Kirschhoffer
 Description : Fast native eternity II puzzle implementation
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "puzzle.h"
#include "tests.h"
#include "parse.h"
#include "solver_mkV.h"

int main(int argc, char** argv) {

	srand48(time(NULL));

	int testResults = tests();

	if (testResults) {
		printf("Tests passed, going on...\n");
	} else {
		printf("Tests failed !\n");
		return 1;
	}

	quad_t grid[GRID_POSITIONS];
	if (argc == 1) {
		parseGrid(grid, stdin);
	} else {
		FILE* fptr = fopen(argv[1], "r");
		if (fptr != NULL) {
			parseGrid(grid, fptr);
			fclose(fptr);
		} else {
			printf("Can't open file %s, reading stdin instead.", argv[1]);
			parseGrid(grid, stdin);
		}
	}
	dumpGrid(grid);
	int solved = solve_mkV(grid);

	printf(" Solved: %d\n", solved);
	dumpGrid(grid);
	return 0;
}
