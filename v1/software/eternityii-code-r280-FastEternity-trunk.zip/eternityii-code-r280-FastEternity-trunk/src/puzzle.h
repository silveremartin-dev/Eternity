/*
 * eternity.h
 *
 *  Created on: 7 mars 2009
 *      Author: Yannick Kirschhoffer
 */

#ifndef ETERNITY_H_
#define ETERNITY_H_

#define GRID_SIZE	16
#define GRID_POSITIONS	(GRID_SIZE*GRID_SIZE)
#define GRID_PAIRS (GRID_SIZE*(GRID_SIZE-1)*2)

//#define WEIGHT_FACTOR (2.6+0.7*GRID_SIZE)
#define WEIGHT_FACTOR (2.6+0.6*GRID_SIZE)

typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned long u32;
typedef unsigned long long u64;

typedef u32 quad_t;
typedef u8 pattern_t;
typedef u64 weight_t;
typedef u16 gridoffset_t;
typedef u8 direction_t;

#undef quad

#define OUT_OF_BOUNDS	-1

#define DIR_NORTH	0
#define DIR_EAST	1
#define DIR_SOUTH	2
#define DIR_WEST	3

#define GRID_POSITION_BORDERS(i)  (((i)%GRID_SIZE==0) + ((i)%GRID_SIZE==GRID_SIZE-1) \
								  +((i)/GRID_SIZE==0) + ((i)/GRID_SIZE==GRID_SIZE-1))

#define QUAD(n, e, s, w)  (((quad_t)n)|(((quad_t)e)<<8)|(((quad_t)s)<<16)|(((quad_t)w)<<24))

#define SET_QUAD_PATTERN(quad, dir, pat) ((quad)|=((pat)<<(8*(dir))))
#define GET_QUAD_PATTERN(quad, dir) (pattern_t)(((quad)&(0x000000FF<<(8*(dir))))>>(8*(dir)))

#define COUNT_PATTERN(quad, pat) ( (GET_QUAD_PATTERN(quad,0)==pat) + (GET_QUAD_PATTERN(quad,1)==pat) \
							     + (GET_QUAD_PATTERN(quad,2)==pat) + (GET_QUAD_PATTERN(quad,3)==pat) )

#define OPPOSITE(d)	(((d)+2)%4)
#define LEFT(d)     (((d)+3)%4)
#define RIGHT(d)    (((d)+1)%4)

#define DIRECTION_SIDE_IS_DEFAULT(quad, d) ((GET_QUAD_PATTERN(quad, LEFT(d))  == 0)   \
										 || (GET_QUAD_PATTERN(quad, RIGHT(d)) == 0) )

#define NEIGHBOR_OFFSET(i,dir)  ((dir)==DIR_NORTH?NORTH_OFFSET(i):	\
								 (dir)==DIR_SOUTH?SOUTH_OFFSET(i): \
								 (dir)==DIR_EAST?EAST_OFFSET(i): \
								 WEST_OFFSET(i) \
								)

#define NORTH_OFFSET(i) (((i)<GRID_SIZE)?OUT_OF_BOUNDS:(i)-GRID_SIZE)
#define SOUTH_OFFSET(i) (((i)>=GRID_POSITIONS-GRID_SIZE)?OUT_OF_BOUNDS:(i)+GRID_SIZE)
#define WEST_OFFSET(i) (((i)%GRID_SIZE)==0?OUT_OF_BOUNDS:(i)-1)
#define EAST_OFFSET(i) (((i)%GRID_SIZE)==(GRID_SIZE-1)?OUT_OF_BOUNDS:(i)+1)

#define MATCHING_SIDES(grid,i) (MATCHING_DIRECTION(grid,i,0) + MATCHING_DIRECTION(grid,i,1) \
						      + MATCHING_DIRECTION(grid,i,2) + MATCHING_DIRECTION(grid,i,3))

#define _GQP(grid, i, d)  ((i)==OUT_OF_BOUNDS?0:GET_QUAD_PATTERN(grid[i],d))
#define MATCHING_DIRECTION(grid,i,d) (_GQP(grid, NEIGHBOR_OFFSET(i,d), OPPOSITE(d)) == GET_QUAD_PATTERN(grid[i], d))

#define MISSING_QUAD(grid, i)  QUAD(_GQP(grid, NORTH_OFFSET(i), DIR_SOUTH), \
								    _GQP(grid,  EAST_OFFSET(i), DIR_WEST),  \
									_GQP(grid, SOUTH_OFFSET(i), DIR_NORTH), \
									_GQP(grid,  WEST_OFFSET(i), DIR_EAST))

#define _ROL32(w, bits) (w<<bits|w>>(32-bits))
#define _MD(q1,q2,max) ((max==4)?max:((q1&0xFF000000)==(q2&0xFF000000))	\
									+((q1&0x00FF0000)==(q2&0x00FF0000))	\
									+((q1&0x0000FF00)==(q2&0x0000FF00))	\
									+((q1&0x000000FF)==(q2&0x000000FF)))

#define MATCH_DEGREES(q1,q2,out) { 			\
			out = 0;						\
			register u8 deg;				\
			deg = _MD(q1,q2, out);			\
			if ( deg > out) out = deg;		\
			deg = _MD(q1,_ROL32(q2,8), out);	\
			if ( deg > out) out = deg;			\
			deg = _MD(q1,_ROL32(q2,16), out);	\
			if ( deg > out) out = deg;			\
			deg = _MD(q1,_ROL32(q2,24), out);	\
			if ( deg > out) out = deg;			\
			}

#define _MD4(q1,q2) ((q1&0xFF000000)==(q2&0xFF000000)?((q1&0xFF000000)==0?4:1):0)	\
				   +((q1&0x00FF0000)==(q2&0x00FF0000)?((q1&0x00FF0000)==0?4:1):0)	\
				   +((q1&0x0000FF00)==(q2&0x0000FF00)?((q1&0x0000FF00)==0?4:1):0)	\
				   +((q1&0x000000FF)==(q2&0x000000FF)?((q1&0x000000FF)==0?4:1):0)

#define OPTIMIZE_QUAD_ROTATION(quad, miss) {	\
			u8 bestDir = 0;						\
			u8 bestPair = 0;					\
			u8 d;								\
												\
			for ( d = 0; d < 4; d++ ) {			\
				u8 pair = _MD4(quad, miss);		\
				if ( pair > bestPair ) {		\
					bestDir = d;				\
					bestPair = pair;			\
				}								\
				quad = _ROL32(quad, 8);			\
			}									\
												\
			quad = _ROL32(quad, 8 * bestDir);	\
			}

#define GRID_SWAP(grid, a, b) {					\
			quad_t _qa = grid[a];				\
			quad_t _qb = grid[b];				\
			quad_t _missA = MISSING_QUAD(grid, a);	\
			quad_t _missB = MISSING_QUAD(grid, b);	\
			OPTIMIZE_QUAD_ROTATION(_qa, _missB);	\
			OPTIMIZE_QUAD_ROTATION(_qb, _missA);	\
			grid[a] = _qb;					\
			grid[b] = _qa;					\
			}

#endif /* ETERNITY_H_ */
