/*
 * solver_mkV.c
 *
 *  Created on: 7 mars 2009
 *      Author: yk
 */

#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "puzzle.h"
#include "solver_mkV.h"

#define STATS_UPDATE_INTERVAL 100000
clock_t _stats_start;
u32 _stats_iterations;
u64 _score_sum;

#define STATS_INIT			_stats_iterations=0; _stats_iterations=0; _score_sum=0; _stats_start=clock();
#define STATS_UPDATE(score) {					\
	_stats_iterations++; _score_sum+=score;		\
	if ( _stats_iterations == STATS_UPDATE_INTERVAL ) {		\
		clock_t now = clock();								\
		u32 durationMillis = 1000*(now-_stats_start)/CLOCKS_PER_SEC;	\
		u32 itPerSec = 1000 * _stats_iterations / durationMillis;		\
		printf("   Working at %6ldit/s, average score: %3d\n",			\
					itPerSec,(int)( _score_sum / _stats_iterations));	\
		STATS_INIT														\
	}}

inline weight_t evaluateWeight(const quad_t* grid, const gridoffset_t offs) {
	weight_t weight = 1;
	direction_t d;

	for (d = 0; d < 4; d++) {
		quad_t quad = grid[offs];
		weight_t localWeight;
		localWeight = 1 - MATCHING_DIRECTION(grid, offs, d);

		if (DIRECTION_SIDE_IS_DEFAULT(quad, d)) {
			localWeight *= 2;
		}

		weight += localWeight;
	}

	return weight;
}

inline weight_t _pow(weight_t w, int power) {
	weight_t result = 1;

	while (power-- > 0) {
		result *= w;
	}

	return result;
}

inline void computeWeights(const quad_t* grid, weight_t* weights) {
	gridoffset_t i;
	for (i = 0; i < GRID_POSITIONS; i++) {
		if (0) {
			weights[i] = 0;
		} else {
			weight_t w = evaluateWeight(grid, i);
			w = _pow(w, WEIGHT_FACTOR);
			weights[i] = w;
		}
	}
}

inline gridoffset_t computeSwapCoord(const weight_t* weights) {
	gridoffset_t i;
	weight_t total = 0;

	for (i = 0; i < GRID_POSITIONS; i++) {
		total += weights[i];
	}

	long target = 1 + lrand48() % total;

	for (i = 0; target > 0; i++) {
		target -= weights[i];
	}

	return i - 1;
}

inline void adaptWeights(const quad_t* grid, weight_t* weights,
		gridoffset_t firstSelection) {
	gridoffset_t index;

	// MkII adaptation

	int borders = GRID_POSITION_BORDERS(firstSelection);

	for (index = 0; index < GRID_POSITIONS; index++) {
		if (index == firstSelection) {
			weights[index] = 0;
		} else {
			int defaults = COUNT_PATTERN(grid[index], 0);
			if (borders != defaults) {
				weights[index] = 0;
			}
		}
	}

	// MkV adaptation

	quad_t missing = MISSING_QUAD(grid, firstSelection);

	for (index = 0; index < GRID_POSITIONS; index++) {
		quad_t quad = grid[index];
		u32 degrees;
		MATCH_DEGREES(missing, quad, degrees);
		weights[index] *= (1 + degrees * degrees);
	}
}

void dumpWeights(const weight_t* weights, const gridoffset_t offset) {
	printf("W: ");
	gridoffset_t i;

	for (i = 0; i < GRID_POSITIONS; i++) {
		if (i == offset) {
			printf(" [%3llu]", weights[i]);
		} else {
			printf(" %4llu ", weights[i]);
		}
	}

	printf("\n");

}

int solve_mkV(quad_t* grid) {
	int gridScore = 0;
	int bestScore = 0;
	weight_t weights[GRID_POSITIONS];
	u64 iterations = 0;

	time_t timeStart;
	time(&timeStart);

	STATS_INIT

	do {
		computeWeights(grid, weights);
		gridoffset_t coordA = computeSwapCoord(weights);
		// dumpWeights(weights, coordA);

		adaptWeights(grid, weights, coordA);
		gridoffset_t coordB = computeSwapCoord(weights);
		// dumpWeights(weights, coordB);

		// printf("%8llu: Swapping %d <--> %d\n", iterations, coordA, coordB);
		GRID_SWAP(grid, coordA, coordB);

		gridScore = 0;
		gridoffset_t x, y, i;

		for (y = 0; y < GRID_SIZE; y++) {
			for (x = 0; x < GRID_SIZE; x++) {
				i = x + y * GRID_SIZE;
				quad_t quad = grid[i];

				if (y > 0 && GET_QUAD_PATTERN(quad, DIR_NORTH) != 0) {
					gridScore += MATCHING_DIRECTION(grid, i, DIR_NORTH);
				}

				if (x > 0 && GET_QUAD_PATTERN(quad, DIR_WEST) != 0) {
					gridScore += MATCHING_DIRECTION(grid, i, DIR_WEST);
				}
			}
		}

		if (gridScore > bestScore) {
			printf("   Best score: %3d\n", gridScore);
			fflush(stdout);
			bestScore = gridScore;
		}

		STATS_UPDATE(gridScore)
		iterations++;
	} while (gridScore < GRID_PAIRS);

	time_t timeEnd;
	time(&timeEnd);

	time_t duration = timeEnd - timeStart;

	printf("  %ld seconds\n", duration);
	printf("  %llu iterations\n", iterations);

	return gridScore == GRID_PAIRS;
}

