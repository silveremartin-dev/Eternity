start eternity2.exe --minigui
